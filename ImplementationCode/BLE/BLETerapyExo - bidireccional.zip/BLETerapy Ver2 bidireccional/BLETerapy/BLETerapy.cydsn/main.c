/**************************************************************************
 * @file        main.c
 * @brief       Archivo Main.
 *
 * @details     Este archivo contiene el punto de entrada principal para la 
 *              aplicación de control de una mano robótica, incluyendo la 
 *              configuración de interrupciones, el inicio de conversión de 
 *              ADC y la lógica de control para los motores de los dedos.
 *
 * @version     1.1
 * @date        2024-05-17
 * @author      Jesus Manuel Moncayo Ricardo, Paula Elizabeth Riveros Cortés, 
 *              Maria Lucia Velazquez Peña
 * @institution Pontificia Universidad Javeriana
 *
 *
 * Este archivo es parte de la tesis titulada "Control digital para un exoesqueleto robótico 
 * utilizando un sistema embebido y aplicación móvil para rehabilitación".
*
 * Tesis desarrollada en el marco del proyecto IRehab de la Pontificia Universidad Javeriana.
 * 
 *
 * Director: Julian David Colorado Montaño, PhD
 * Cliente:  Catalina Alvarado Rojas
 *
 * Notas:
 * - Verifique que todas las conexiones de los motores estén correctamente establecidas.
 * 
 ***************************************************************************/



#include "project.h"
#include "BLE.h"
#include "BLE_custom.h"


// Definir constantes y variables globales
#define TRAJ_END 700   // Valor de referencia para el final de la trayectoria
#define TRAJ_BEG 150   // Valor de referencia para el inicio de la trayectoria
#define REPITIS 10      // Número de repeticiones
#define KP 0.8         // Ganancia proporcional (Kp)
#define KD 0.6         // Ganancia derivativa (Kd*1000)

// Variables globales para almacenar errores previos y banderas de control
int16_t errorAnterior_1 = 0, errorAnterior_2 = 0, errorAnterior_3 = 0, errorAnterior_4 = 0;
uint8 flag_sample = 0, flag_first = 0, flag_Rep = 0, terr = 0, repts = 0, conn = 0;
volatile uint8 notifyEnabled = 0;   // 1 = el cliente habilitó NOTIFY en F2


// Interrupción para manejo de muestras de conversión ADC
CY_ISR(InterruptSample) {
    SAR_IsEndConversion(SAR_WAIT_FOR_RESULT);  // Esperar resultado de conversión ADC
    flag_sample = 1;                           // Activar bandera de muestra lista
    SampleT_ClearInterrupt(SampleT_INTR_MASK_TC);  // Limpiar interrupción del temporizador
}

CY_ISR(InterruptRepeate)
{
    if (terr != 0) {
        flag_Rep = !flag_Rep;   // cada toggle = medio ciclo
        repts++;

        if (repts >= (REPITIS * 2)) {   // 10 ciclos => 20 toggles
            terr = 0;
            repts = 0;
            flag_Rep = 0;
            Rep_Timer_Stop();
        }
    }

    // Limpia la bandera de interrupción del timer
    Rep_Timer_ClearInterrupt(Rep_Timer_INTR_MASK_TC);

    // Si la terapia sigue activa y el timer es one-shot, rearmarlo para el siguiente disparo
    if (terr != 0) {
        Rep_Timer_WriteCounter(0);
        Rep_Timer_Start();
    }
}


// Declaración de funciones de control y rutina de terapia
void terapy_routine(int8_t terapy, int16_t setpoint);
void control_indice(int16_t setpoint);
void control_corazon(int16_t setpoint);
void control_anular(int16_t setpoint);
void control_menique(int16_t setpoint);
static void BLE_SendActuatorTelemetry(void);


// ===================== BLE Notify helper (uint16 -> uint8[8]) =====================
// Empaca 4 canales ADC (uint16) en 8 bytes (LSB primero) y los envía por NOTIFY.
static void BLE_SendActuatorTelemetry(void)
{
    if (CyBle_GetState() != CYBLE_STATE_CONNECTED) return;
    if (!notifyEnabled) return;

    uint16 v0 = SAR_GetResult16(0);
    uint16 v1 = SAR_GetResult16(1);
    uint16 v2 = SAR_GetResult16(2);
    uint16 v3 = SAR_GetResult16(3);

    static uint8 payload[8];
    payload[0] = (uint8)(v0 & 0xFF);       // v0 LSB
    payload[1] = (uint8)((v0 >> 8) & 0xFF);// v0 MSB
    payload[2] = (uint8)(v1 & 0xFF);       // v1 LSB
    payload[3] = (uint8)((v1 >> 8) & 0xFF);// v1 MSB
    payload[4] = (uint8)(v2 & 0xFF);       // v2 LSB
    payload[5] = (uint8)((v2 >> 8) & 0xFF);// v2 MSB
    payload[6] = (uint8)(v3 & 0xFF);       // v3 LSB
    payload[7] = (uint8)((v3 >> 8) & 0xFF);// v3 MSB

    CYBLE_GATTS_HANDLE_VALUE_NTF_T ntf;
    ntf.attrHandle = CYBLE_SENDACTUADORVALUE_CUSTOM_CHARACTERISTIC_CHAR_HANDLE;
    ntf.value.val  = payload;
    ntf.value.len  = 8u; // ahora son 8 bytes

    (void)CyBle_GattsNotification(cyBle_connHandle, &ntf);
}
// ================================================================================



// Callback para manejar eventos BLE
void AppCallBack(uint32 event, void* eventParam) { 
    CYBLE_GATTS_WRITE_REQ_PARAM_T *wrReqParam;
     
    switch(event) { 
      case CYBLE_EVT_STACK_ON:
            CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST); 
        break; 
    
      case CYBLE_EVT_GAP_DEVICE_CONNECTED:
            LED_A_Write(1);
            LED_B_Write(1);
            conn = 1;                  // <-- NUEVO: marcar conectado
        break;
      
      case CYBLE_EVT_GATTS_WRITE_REQ:
        wrReqParam = (CYBLE_GATTS_WRITE_REQ_PARAM_T *) eventParam;

        // Manejar escritura en característica personalizada
        if (wrReqParam->handleValPair.attrHandle == CYBLE_TRAJECTORY_CUSTOM_CHARACTERISTIC_CHAR_HANDLE) {
            if (CYBLE_GATT_ERR_NONE == CyBle_GattsWriteAttributeValue(&wrReqParam->handleValPair, 0, &cyBle_connHandle, CYBLE_GATT_DB_PEER_INITIATED)) {
                // Interpretar el valor recibido y controlar los LEDs y la terapia
                switch (wrReqParam->handleValPair.value.val[0]) {
                    case 0x01:
                        terr = 1;
                        flag_first = 0;
                        flag_Rep = 1;
                        repts = 0;  // añade esto en 0x01..0x05 (ya lo tienes en 0x00)
                        break;
                    case 0x02:               
                        terr = 2;
                        flag_first = 0;
                        flag_Rep = 1;
                        repts = 0;  // añade esto en 0x01..0x05 (ya lo tienes en 0x00)
                        break;
                    case 0x03:
                        terr = 3;
                        flag_first = 0;
                        flag_Rep = 1;
                        repts = 0;  // añade esto en 0x01..0x05 (ya lo tienes en 0x00)
                        break;
                    case 0x04: 
                        terr = 4;
                        flag_first = 0;
                        flag_Rep = 1;
                        repts = 0;  // añade esto en 0x01..0x05 (ya lo tienes en 0x00)
                        break;
                    case 0x05:
                        terr = 5;
                        flag_first = 0;
                        flag_Rep = 1;
                        repts = 0;  // añade esto en 0x01..0x05 (ya lo tienes en 0x00)

                        break;
                    case 0x00: 
                        terr = 0;
                        flag_first = 0;
                        flag_Rep = 0; // SE CAMBIO DE 1  A 0
                        repts = 0;
                        break;
                }
                CyBle_GattsWriteRsp(cyBle_connHandle);  // Responder a la escritura
            }
        }
        else if (wrReqParam->handleValPair.attrHandle ==
                     CYBLE_SENDACTUADORVALUE_CUSTOM_CHARACTERISTIC_CLIENT_CHARACTERISTIC_CONFIGURATION_DESC_HANDLE)
        {
            uint8 cccd0 = wrReqParam->handleValPair.value.val[0]; // bit0=Notify, bit1=Indicate
            notifyEnabled = (cccd0 & 0x01u) ? 1u : 0u;

            (void)CyBle_GattsWriteAttributeValue(&wrReqParam->handleValPair, 0,
                                                 &cyBle_connHandle, CYBLE_GATT_DB_PEER_INITIATED);
            CyBle_GattsWriteRsp(cyBle_connHandle);
        }
        break;   
      case CYBLE_EVT_GAP_DEVICE_DISCONNECTED:
        LED_A_Write(0);
        LED_B_Write(0);
        conn = 0;                      // <-- NUEVO: marcar desconectado
        notifyEnabled = 0;   // <-- limpiar estado CCCD
        CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST);
        break;
    } 
} 

int main(void) {
    CyGlobalIntEnable; /* Habilitar interrupciones globales */
    SampleT_Start();
    Rep_Timer_Start();
    Rep_Timer_Stop();
    Sample_Clock_Start();
    isrS_StartEx(InterruptSample);
    isrR_StartEx(InterruptRepeate);
    LED_A_Write(0);
    LED_B_Write(0);
    SAR_Start();
    SAR_StartConvert();
    terr = 0;
    repts = 0;
    CyBle_Start(AppCallBack);
     
    /* Esperar a que el componente BLE se inicialice */
    while (CyBle_GetState() == CYBLE_STATE_INITIALIZING) {
        CyBle_ProcessEvents(); 
    } 
    /*
    // Código de inicialización o arranque 
    for(int i = 0; i>65000;i++){
        terapy_routine(5,TRAJ_BEG);
        CyDelayUs(9600);
    }
    */
    for(;;) {
        CyBle_ProcessEvents();
        /* Código principal de la aplicación */
        if (flag_sample) {
            if (!flag_Rep) {
                terapy_routine(terr, TRAJ_BEG);
            } else {
                terapy_routine(terr, TRAJ_END);
            }
            
            BLE_SendActuatorTelemetry();         
            
            flag_sample = 0;
        } 
    }
}

// Función de rutina de terapia
void terapy_routine(int8_t terapy, int16_t setpoint) {
    if (flag_first == 0) {
        flag_first = 1;
        Rep_Timer_Start();
        Rep_Timer_WriteCounter(0);
    }
    switch (terapy) {
        case 1:
            control_indice(setpoint);
            control_corazon(TRAJ_BEG);
            control_anular(TRAJ_BEG);
            control_menique(TRAJ_BEG);            
            break;
        case 2:
            control_indice(TRAJ_BEG);
            control_corazon(setpoint);
            control_anular(TRAJ_BEG);
            control_menique(TRAJ_BEG);
            break;
        case 3:
            control_indice(TRAJ_BEG);
            control_corazon(TRAJ_BEG);
            control_anular(setpoint);
            control_menique(TRAJ_BEG);
            break;
        case 4:
            control_indice(TRAJ_BEG);
            control_corazon(TRAJ_BEG);
            control_anular(TRAJ_BEG);
            control_menique(setpoint);
            break;
        case 5:
            control_indice(setpoint);
            control_corazon(setpoint);
            control_anular(setpoint);
            control_menique(setpoint);
            break;
        default:
            control_indice(TRAJ_BEG);
            control_corazon(TRAJ_BEG);
            control_anular(TRAJ_BEG);
            control_menique(TRAJ_BEG);  
            break;
    }
}

// Función de control para el dedo índice
void control_indice(int16_t setpoint) {
    int16_t valorActual;
    int16_t error;
    int16_t derivadaError;
    float salida;

    // Leer valor del ADC (A0)
    valorActual = SAR_GetResult16(0);

    // Calcular el error
    error = setpoint - valorActual;

    // Calcular la derivada del error
    derivadaError = (error - errorAnterior_1);

    // Calcular la salida del controlador PD
    salida = KP * (float)error + KD * (float)derivadaError;

    // Actualizar el error anterior
    errorAnterior_1 = error;

    // Controlar el motor usando la salida del controlador PD
    if (salida > 40) {
        // Hacer girar el motor en una dirección
        IN_1_1_Write(1);
        IN_2_1_Write(0);
    } else if (salida < -40) {
        // Hacer girar el motor en la dirección opuesta
        IN_1_1_Write(0);
        IN_2_1_Write(1);
    } else {
        // Detener el motor
        IN_1_1_Write(1);
        IN_2_1_Write(1);
    }
}

// Función de control para el dedo corazón
void control_corazon(int16_t setpoint) {
    int16_t valorActual;
    int16_t error;
    int16_t derivadaError;
    float salida;

    // Leer valor del ADC (A1) para el dedo corazón
    valorActual = SAR_GetResult16(1);

    // Calcular el error
    error = setpoint - valorActual;

    // Calcular la derivada del error
    derivadaError = (error - errorAnterior_2);

    // Calcular la salida del controlador PD
    salida = KP * (float)error + KD * (float)derivadaError;

    // Actualizar el error anterior
    errorAnterior_2 = error;

    // Controlar el motor usando la salida del controlador PD
    if (salida > 30) {
        // Hacer girar el motor en una dirección para el dedo corazón
        IN_1_2_Write(1);
        IN_2_2_Write(0);
    } else if (salida < -30) {
        // Hacer girar el motor en la dirección opuesta para el dedo corazón
        IN_1_2_Write(0);
        IN_2_2_Write(1);
    } else {
        // Detener el motor para el dedo corazón
        IN_1_2_Write(1);
        IN_2_2_Write(1);
    }
}

// Función de control para el dedo anular
void control_anular(int16_t setpoint) {
    int16_t valorActual;
    int16_t error;
    int16_t derivadaError;          
    float salida;

    // Leer valor del ADC (A2) para el dedo anular
    valorActual = SAR_GetResult16(2);

    // Calcular el error
    error = setpoint - valorActual;

    // Calcular la derivada del error
    derivadaError = (error - errorAnterior_3);

    // Calcular la salida del controlador PD
    salida = KP * (float)error + KD * (float)derivadaError;

    // Actualizar el error anterior
    errorAnterior_3 = error;

    // Controlar el motor usando la salida del controlador PD
    if (salida > 40) {
        // Hacer girar el motor en una dirección para el dedo anular
        IN_1_3_Write(1);
        IN_2_3_Write(0);
    } else if (salida < -40) {
        // Hacer girar el motor en la dirección opuesta para el dedo anular
        IN_1_3_Write(0);
        IN_2_3_Write(1);
    } else {
        // Detener el motor para el dedo anular
        IN_1_3_Write(1);
        IN_2_3_Write(1);
    }
}

// Función de control para el dedo meñique
void control_menique(int16_t setpoint) {
    int16_t valorActual;
    int16_t error;
    int16_t derivadaError;
    float salida;

    // Leer valor del ADC (A3) para el dedo meñique
    valorActual = SAR_GetResult16(3);

    // Calcular el error
    error = setpoint - valorActual;

    // Calcular la derivada del error
    derivadaError = (error - errorAnterior_4);

    // Calcular la salida del controlador PD
    salida = KP * (float)error + KD * (float)derivadaError;

    // Actualizar el error anterior
    errorAnterior_4 = error;

    // Controlar el motor usando la salida del controlador PD
    if (salida > 40) {
        // Hacer girar el motor en una dirección para el dedo meñique
        IN_1_4_Write(1);
        IN_2_4_Write(0);
    } else if (salida < -40) {
        // Hacer girar el motor en la dirección opuesta para el dedo meñique
        IN_1_4_Write(0);
        IN_2_4_Write(1);
    } else {
        // Detener el motor para el dedo meñique
        IN_1_4_Write(1);
        IN_2_4_Write(1);
    }
}

/* [] END OF FILE */
