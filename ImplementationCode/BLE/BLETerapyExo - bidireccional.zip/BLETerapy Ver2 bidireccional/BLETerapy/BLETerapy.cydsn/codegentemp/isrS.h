/*******************************************************************************
* File Name: isrS.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_isrS_H)
#define CY_ISR_isrS_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void isrS_Start(void);
void isrS_StartEx(cyisraddress address);
void isrS_Stop(void);

CY_ISR_PROTO(isrS_Interrupt);

void isrS_SetVector(cyisraddress address);
cyisraddress isrS_GetVector(void);

void isrS_SetPriority(uint8 priority);
uint8 isrS_GetPriority(void);

void isrS_Enable(void);
uint8 isrS_GetState(void);
void isrS_Disable(void);

void isrS_SetPending(void);
void isrS_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the isrS ISR. */
#define isrS_INTC_VECTOR            ((reg32 *) isrS__INTC_VECT)

/* Address of the isrS ISR priority. */
#define isrS_INTC_PRIOR             ((reg32 *) isrS__INTC_PRIOR_REG)

/* Priority of the isrS interrupt. */
#define isrS_INTC_PRIOR_NUMBER      isrS__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable isrS interrupt. */
#define isrS_INTC_SET_EN            ((reg32 *) isrS__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the isrS interrupt. */
#define isrS_INTC_CLR_EN            ((reg32 *) isrS__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the isrS interrupt state to pending. */
#define isrS_INTC_SET_PD            ((reg32 *) isrS__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the isrS interrupt. */
#define isrS_INTC_CLR_PD            ((reg32 *) isrS__INTC_CLR_PD_REG)



#endif /* CY_ISR_isrS_H */


/* [] END OF FILE */
