/*******************************************************************************
* File Name: SampleT.h
* Version 2.10
*
* Description:
*  This file provides constants and parameter values for the SampleT
*  component.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_TCPWM_SampleT_H)
#define CY_TCPWM_SampleT_H


#include "CyLib.h"
#include "cytypes.h"
#include "cyfitter.h"


/*******************************************************************************
* Internal Type defines
*******************************************************************************/

/* Structure to save state before go to sleep */
typedef struct
{
    uint8  enableState;
} SampleT_BACKUP_STRUCT;


/*******************************************************************************
* Variables
*******************************************************************************/
extern uint8  SampleT_initVar;


/***************************************
*   Conditional Compilation Parameters
****************************************/

#define SampleT_CY_TCPWM_V2                    (CYIPBLOCK_m0s8tcpwm_VERSION == 2u)
#define SampleT_CY_TCPWM_4000                  (CY_PSOC4_4000)

/* TCPWM Configuration */
#define SampleT_CONFIG                         (1lu)

/* Quad Mode */
/* Parameters */
#define SampleT_QUAD_ENCODING_MODES            (0lu)
#define SampleT_QUAD_AUTO_START                (1lu)

/* Signal modes */
#define SampleT_QUAD_INDEX_SIGNAL_MODE         (0lu)
#define SampleT_QUAD_PHIA_SIGNAL_MODE          (3lu)
#define SampleT_QUAD_PHIB_SIGNAL_MODE          (3lu)
#define SampleT_QUAD_STOP_SIGNAL_MODE          (0lu)

/* Signal present */
#define SampleT_QUAD_INDEX_SIGNAL_PRESENT      (0lu)
#define SampleT_QUAD_STOP_SIGNAL_PRESENT       (0lu)

/* Interrupt Mask */
#define SampleT_QUAD_INTERRUPT_MASK            (1lu)

/* Timer/Counter Mode */
/* Parameters */
#define SampleT_TC_RUN_MODE                    (0lu)
#define SampleT_TC_COUNTER_MODE                (0lu)
#define SampleT_TC_COMP_CAP_MODE               (2lu)
#define SampleT_TC_PRESCALER                   (0lu)

/* Signal modes */
#define SampleT_TC_RELOAD_SIGNAL_MODE          (0lu)
#define SampleT_TC_COUNT_SIGNAL_MODE           (3lu)
#define SampleT_TC_START_SIGNAL_MODE           (0lu)
#define SampleT_TC_STOP_SIGNAL_MODE            (0lu)
#define SampleT_TC_CAPTURE_SIGNAL_MODE         (0lu)

/* Signal present */
#define SampleT_TC_RELOAD_SIGNAL_PRESENT       (0lu)
#define SampleT_TC_COUNT_SIGNAL_PRESENT        (0lu)
#define SampleT_TC_START_SIGNAL_PRESENT        (0lu)
#define SampleT_TC_STOP_SIGNAL_PRESENT         (0lu)
#define SampleT_TC_CAPTURE_SIGNAL_PRESENT      (0lu)

/* Interrupt Mask */
#define SampleT_TC_INTERRUPT_MASK              (1lu)

/* PWM Mode */
/* Parameters */
#define SampleT_PWM_KILL_EVENT                 (0lu)
#define SampleT_PWM_STOP_EVENT                 (0lu)
#define SampleT_PWM_MODE                       (4lu)
#define SampleT_PWM_OUT_N_INVERT               (0lu)
#define SampleT_PWM_OUT_INVERT                 (0lu)
#define SampleT_PWM_ALIGN                      (0lu)
#define SampleT_PWM_RUN_MODE                   (0lu)
#define SampleT_PWM_DEAD_TIME_CYCLE            (0lu)
#define SampleT_PWM_PRESCALER                  (0lu)

/* Signal modes */
#define SampleT_PWM_RELOAD_SIGNAL_MODE         (0lu)
#define SampleT_PWM_COUNT_SIGNAL_MODE          (3lu)
#define SampleT_PWM_START_SIGNAL_MODE          (0lu)
#define SampleT_PWM_STOP_SIGNAL_MODE           (0lu)
#define SampleT_PWM_SWITCH_SIGNAL_MODE         (0lu)

/* Signal present */
#define SampleT_PWM_RELOAD_SIGNAL_PRESENT      (0lu)
#define SampleT_PWM_COUNT_SIGNAL_PRESENT       (0lu)
#define SampleT_PWM_START_SIGNAL_PRESENT       (0lu)
#define SampleT_PWM_STOP_SIGNAL_PRESENT        (0lu)
#define SampleT_PWM_SWITCH_SIGNAL_PRESENT      (0lu)

/* Interrupt Mask */
#define SampleT_PWM_INTERRUPT_MASK             (1lu)


/***************************************
*    Initial Parameter Constants
***************************************/

/* Timer/Counter Mode */
#define SampleT_TC_PERIOD_VALUE                (15000lu)
#define SampleT_TC_COMPARE_VALUE               (65535lu)
#define SampleT_TC_COMPARE_BUF_VALUE           (65535lu)
#define SampleT_TC_COMPARE_SWAP                (0lu)

/* PWM Mode */
#define SampleT_PWM_PERIOD_VALUE               (65535lu)
#define SampleT_PWM_PERIOD_BUF_VALUE           (65535lu)
#define SampleT_PWM_PERIOD_SWAP                (0lu)
#define SampleT_PWM_COMPARE_VALUE              (65535lu)
#define SampleT_PWM_COMPARE_BUF_VALUE          (65535lu)
#define SampleT_PWM_COMPARE_SWAP               (0lu)


/***************************************
*    Enumerated Types and Parameters
***************************************/

#define SampleT__LEFT 0
#define SampleT__RIGHT 1
#define SampleT__CENTER 2
#define SampleT__ASYMMETRIC 3

#define SampleT__X1 0
#define SampleT__X2 1
#define SampleT__X4 2

#define SampleT__PWM 4
#define SampleT__PWM_DT 5
#define SampleT__PWM_PR 6

#define SampleT__INVERSE 1
#define SampleT__DIRECT 0

#define SampleT__CAPTURE 2
#define SampleT__COMPARE 0

#define SampleT__TRIG_LEVEL 3
#define SampleT__TRIG_RISING 0
#define SampleT__TRIG_FALLING 1
#define SampleT__TRIG_BOTH 2

#define SampleT__INTR_MASK_TC 1
#define SampleT__INTR_MASK_CC_MATCH 2
#define SampleT__INTR_MASK_NONE 0
#define SampleT__INTR_MASK_TC_CC 3

#define SampleT__UNCONFIG 8
#define SampleT__TIMER 1
#define SampleT__QUAD 3
#define SampleT__PWM_SEL 7

#define SampleT__COUNT_UP 0
#define SampleT__COUNT_DOWN 1
#define SampleT__COUNT_UPDOWN0 2
#define SampleT__COUNT_UPDOWN1 3


/* Prescaler */
#define SampleT_PRESCALE_DIVBY1                ((uint32)(0u << SampleT_PRESCALER_SHIFT))
#define SampleT_PRESCALE_DIVBY2                ((uint32)(1u << SampleT_PRESCALER_SHIFT))
#define SampleT_PRESCALE_DIVBY4                ((uint32)(2u << SampleT_PRESCALER_SHIFT))
#define SampleT_PRESCALE_DIVBY8                ((uint32)(3u << SampleT_PRESCALER_SHIFT))
#define SampleT_PRESCALE_DIVBY16               ((uint32)(4u << SampleT_PRESCALER_SHIFT))
#define SampleT_PRESCALE_DIVBY32               ((uint32)(5u << SampleT_PRESCALER_SHIFT))
#define SampleT_PRESCALE_DIVBY64               ((uint32)(6u << SampleT_PRESCALER_SHIFT))
#define SampleT_PRESCALE_DIVBY128              ((uint32)(7u << SampleT_PRESCALER_SHIFT))

/* TCPWM set modes */
#define SampleT_MODE_TIMER_COMPARE             ((uint32)(SampleT__COMPARE         <<  \
                                                                  SampleT_MODE_SHIFT))
#define SampleT_MODE_TIMER_CAPTURE             ((uint32)(SampleT__CAPTURE         <<  \
                                                                  SampleT_MODE_SHIFT))
#define SampleT_MODE_QUAD                      ((uint32)(SampleT__QUAD            <<  \
                                                                  SampleT_MODE_SHIFT))
#define SampleT_MODE_PWM                       ((uint32)(SampleT__PWM             <<  \
                                                                  SampleT_MODE_SHIFT))
#define SampleT_MODE_PWM_DT                    ((uint32)(SampleT__PWM_DT          <<  \
                                                                  SampleT_MODE_SHIFT))
#define SampleT_MODE_PWM_PR                    ((uint32)(SampleT__PWM_PR          <<  \
                                                                  SampleT_MODE_SHIFT))

/* Quad Modes */
#define SampleT_MODE_X1                        ((uint32)(SampleT__X1              <<  \
                                                                  SampleT_QUAD_MODE_SHIFT))
#define SampleT_MODE_X2                        ((uint32)(SampleT__X2              <<  \
                                                                  SampleT_QUAD_MODE_SHIFT))
#define SampleT_MODE_X4                        ((uint32)(SampleT__X4              <<  \
                                                                  SampleT_QUAD_MODE_SHIFT))

/* Counter modes */
#define SampleT_COUNT_UP                       ((uint32)(SampleT__COUNT_UP        <<  \
                                                                  SampleT_UPDOWN_SHIFT))
#define SampleT_COUNT_DOWN                     ((uint32)(SampleT__COUNT_DOWN      <<  \
                                                                  SampleT_UPDOWN_SHIFT))
#define SampleT_COUNT_UPDOWN0                  ((uint32)(SampleT__COUNT_UPDOWN0   <<  \
                                                                  SampleT_UPDOWN_SHIFT))
#define SampleT_COUNT_UPDOWN1                  ((uint32)(SampleT__COUNT_UPDOWN1   <<  \
                                                                  SampleT_UPDOWN_SHIFT))

/* PWM output invert */
#define SampleT_INVERT_LINE                    ((uint32)(SampleT__INVERSE         <<  \
                                                                  SampleT_INV_OUT_SHIFT))
#define SampleT_INVERT_LINE_N                  ((uint32)(SampleT__INVERSE         <<  \
                                                                  SampleT_INV_COMPL_OUT_SHIFT))

/* Trigger modes */
#define SampleT_TRIG_RISING                    ((uint32)SampleT__TRIG_RISING)
#define SampleT_TRIG_FALLING                   ((uint32)SampleT__TRIG_FALLING)
#define SampleT_TRIG_BOTH                      ((uint32)SampleT__TRIG_BOTH)
#define SampleT_TRIG_LEVEL                     ((uint32)SampleT__TRIG_LEVEL)

/* Interrupt mask */
#define SampleT_INTR_MASK_TC                   ((uint32)SampleT__INTR_MASK_TC)
#define SampleT_INTR_MASK_CC_MATCH             ((uint32)SampleT__INTR_MASK_CC_MATCH)

/* PWM Output Controls */
#define SampleT_CC_MATCH_SET                   (0x00u)
#define SampleT_CC_MATCH_CLEAR                 (0x01u)
#define SampleT_CC_MATCH_INVERT                (0x02u)
#define SampleT_CC_MATCH_NO_CHANGE             (0x03u)
#define SampleT_OVERLOW_SET                    (0x00u)
#define SampleT_OVERLOW_CLEAR                  (0x04u)
#define SampleT_OVERLOW_INVERT                 (0x08u)
#define SampleT_OVERLOW_NO_CHANGE              (0x0Cu)
#define SampleT_UNDERFLOW_SET                  (0x00u)
#define SampleT_UNDERFLOW_CLEAR                (0x10u)
#define SampleT_UNDERFLOW_INVERT               (0x20u)
#define SampleT_UNDERFLOW_NO_CHANGE            (0x30u)

/* PWM Align */
#define SampleT_PWM_MODE_LEFT                  (SampleT_CC_MATCH_CLEAR        |   \
                                                         SampleT_OVERLOW_SET           |   \
                                                         SampleT_UNDERFLOW_NO_CHANGE)
#define SampleT_PWM_MODE_RIGHT                 (SampleT_CC_MATCH_SET          |   \
                                                         SampleT_OVERLOW_NO_CHANGE     |   \
                                                         SampleT_UNDERFLOW_CLEAR)
#define SampleT_PWM_MODE_ASYM                  (SampleT_CC_MATCH_INVERT       |   \
                                                         SampleT_OVERLOW_SET           |   \
                                                         SampleT_UNDERFLOW_CLEAR)

#if (SampleT_CY_TCPWM_V2)
    #if(SampleT_CY_TCPWM_4000)
        #define SampleT_PWM_MODE_CENTER                (SampleT_CC_MATCH_INVERT       |   \
                                                                 SampleT_OVERLOW_NO_CHANGE     |   \
                                                                 SampleT_UNDERFLOW_CLEAR)
    #else
        #define SampleT_PWM_MODE_CENTER                (SampleT_CC_MATCH_INVERT       |   \
                                                                 SampleT_OVERLOW_SET           |   \
                                                                 SampleT_UNDERFLOW_CLEAR)
    #endif /* (SampleT_CY_TCPWM_4000) */
#else
    #define SampleT_PWM_MODE_CENTER                (SampleT_CC_MATCH_INVERT       |   \
                                                             SampleT_OVERLOW_NO_CHANGE     |   \
                                                             SampleT_UNDERFLOW_CLEAR)
#endif /* (SampleT_CY_TCPWM_NEW) */

/* Command operations without condition */
#define SampleT_CMD_CAPTURE                    (0u)
#define SampleT_CMD_RELOAD                     (8u)
#define SampleT_CMD_STOP                       (16u)
#define SampleT_CMD_START                      (24u)

/* Status */
#define SampleT_STATUS_DOWN                    (1u)
#define SampleT_STATUS_RUNNING                 (2u)


/***************************************
*        Function Prototypes
****************************************/

void   SampleT_Init(void);
void   SampleT_Enable(void);
void   SampleT_Start(void);
void   SampleT_Stop(void);

void   SampleT_SetMode(uint32 mode);
void   SampleT_SetCounterMode(uint32 counterMode);
void   SampleT_SetPWMMode(uint32 modeMask);
void   SampleT_SetQDMode(uint32 qdMode);

void   SampleT_SetPrescaler(uint32 prescaler);
void   SampleT_TriggerCommand(uint32 mask, uint32 command);
void   SampleT_SetOneShot(uint32 oneShotEnable);
uint32 SampleT_ReadStatus(void);

void   SampleT_SetPWMSyncKill(uint32 syncKillEnable);
void   SampleT_SetPWMStopOnKill(uint32 stopOnKillEnable);
void   SampleT_SetPWMDeadTime(uint32 deadTime);
void   SampleT_SetPWMInvert(uint32 mask);

void   SampleT_SetInterruptMode(uint32 interruptMask);
uint32 SampleT_GetInterruptSourceMasked(void);
uint32 SampleT_GetInterruptSource(void);
void   SampleT_ClearInterrupt(uint32 interruptMask);
void   SampleT_SetInterrupt(uint32 interruptMask);

void   SampleT_WriteCounter(uint32 count);
uint32 SampleT_ReadCounter(void);

uint32 SampleT_ReadCapture(void);
uint32 SampleT_ReadCaptureBuf(void);

void   SampleT_WritePeriod(uint32 period);
uint32 SampleT_ReadPeriod(void);
void   SampleT_WritePeriodBuf(uint32 periodBuf);
uint32 SampleT_ReadPeriodBuf(void);

void   SampleT_WriteCompare(uint32 compare);
uint32 SampleT_ReadCompare(void);
void   SampleT_WriteCompareBuf(uint32 compareBuf);
uint32 SampleT_ReadCompareBuf(void);

void   SampleT_SetPeriodSwap(uint32 swapEnable);
void   SampleT_SetCompareSwap(uint32 swapEnable);

void   SampleT_SetCaptureMode(uint32 triggerMode);
void   SampleT_SetReloadMode(uint32 triggerMode);
void   SampleT_SetStartMode(uint32 triggerMode);
void   SampleT_SetStopMode(uint32 triggerMode);
void   SampleT_SetCountMode(uint32 triggerMode);

void   SampleT_SaveConfig(void);
void   SampleT_RestoreConfig(void);
void   SampleT_Sleep(void);
void   SampleT_Wakeup(void);


/***************************************
*             Registers
***************************************/

#define SampleT_BLOCK_CONTROL_REG              (*(reg32 *) SampleT_cy_m0s8_tcpwm_1__TCPWM_CTRL )
#define SampleT_BLOCK_CONTROL_PTR              ( (reg32 *) SampleT_cy_m0s8_tcpwm_1__TCPWM_CTRL )
#define SampleT_COMMAND_REG                    (*(reg32 *) SampleT_cy_m0s8_tcpwm_1__TCPWM_CMD )
#define SampleT_COMMAND_PTR                    ( (reg32 *) SampleT_cy_m0s8_tcpwm_1__TCPWM_CMD )
#define SampleT_INTRRUPT_CAUSE_REG             (*(reg32 *) SampleT_cy_m0s8_tcpwm_1__TCPWM_INTR_CAUSE )
#define SampleT_INTRRUPT_CAUSE_PTR             ( (reg32 *) SampleT_cy_m0s8_tcpwm_1__TCPWM_INTR_CAUSE )
#define SampleT_CONTROL_REG                    (*(reg32 *) SampleT_cy_m0s8_tcpwm_1__CTRL )
#define SampleT_CONTROL_PTR                    ( (reg32 *) SampleT_cy_m0s8_tcpwm_1__CTRL )
#define SampleT_STATUS_REG                     (*(reg32 *) SampleT_cy_m0s8_tcpwm_1__STATUS )
#define SampleT_STATUS_PTR                     ( (reg32 *) SampleT_cy_m0s8_tcpwm_1__STATUS )
#define SampleT_COUNTER_REG                    (*(reg32 *) SampleT_cy_m0s8_tcpwm_1__COUNTER )
#define SampleT_COUNTER_PTR                    ( (reg32 *) SampleT_cy_m0s8_tcpwm_1__COUNTER )
#define SampleT_COMP_CAP_REG                   (*(reg32 *) SampleT_cy_m0s8_tcpwm_1__CC )
#define SampleT_COMP_CAP_PTR                   ( (reg32 *) SampleT_cy_m0s8_tcpwm_1__CC )
#define SampleT_COMP_CAP_BUF_REG               (*(reg32 *) SampleT_cy_m0s8_tcpwm_1__CC_BUFF )
#define SampleT_COMP_CAP_BUF_PTR               ( (reg32 *) SampleT_cy_m0s8_tcpwm_1__CC_BUFF )
#define SampleT_PERIOD_REG                     (*(reg32 *) SampleT_cy_m0s8_tcpwm_1__PERIOD )
#define SampleT_PERIOD_PTR                     ( (reg32 *) SampleT_cy_m0s8_tcpwm_1__PERIOD )
#define SampleT_PERIOD_BUF_REG                 (*(reg32 *) SampleT_cy_m0s8_tcpwm_1__PERIOD_BUFF )
#define SampleT_PERIOD_BUF_PTR                 ( (reg32 *) SampleT_cy_m0s8_tcpwm_1__PERIOD_BUFF )
#define SampleT_TRIG_CONTROL0_REG              (*(reg32 *) SampleT_cy_m0s8_tcpwm_1__TR_CTRL0 )
#define SampleT_TRIG_CONTROL0_PTR              ( (reg32 *) SampleT_cy_m0s8_tcpwm_1__TR_CTRL0 )
#define SampleT_TRIG_CONTROL1_REG              (*(reg32 *) SampleT_cy_m0s8_tcpwm_1__TR_CTRL1 )
#define SampleT_TRIG_CONTROL1_PTR              ( (reg32 *) SampleT_cy_m0s8_tcpwm_1__TR_CTRL1 )
#define SampleT_TRIG_CONTROL2_REG              (*(reg32 *) SampleT_cy_m0s8_tcpwm_1__TR_CTRL2 )
#define SampleT_TRIG_CONTROL2_PTR              ( (reg32 *) SampleT_cy_m0s8_tcpwm_1__TR_CTRL2 )
#define SampleT_INTERRUPT_REQ_REG              (*(reg32 *) SampleT_cy_m0s8_tcpwm_1__INTR )
#define SampleT_INTERRUPT_REQ_PTR              ( (reg32 *) SampleT_cy_m0s8_tcpwm_1__INTR )
#define SampleT_INTERRUPT_SET_REG              (*(reg32 *) SampleT_cy_m0s8_tcpwm_1__INTR_SET )
#define SampleT_INTERRUPT_SET_PTR              ( (reg32 *) SampleT_cy_m0s8_tcpwm_1__INTR_SET )
#define SampleT_INTERRUPT_MASK_REG             (*(reg32 *) SampleT_cy_m0s8_tcpwm_1__INTR_MASK )
#define SampleT_INTERRUPT_MASK_PTR             ( (reg32 *) SampleT_cy_m0s8_tcpwm_1__INTR_MASK )
#define SampleT_INTERRUPT_MASKED_REG           (*(reg32 *) SampleT_cy_m0s8_tcpwm_1__INTR_MASKED )
#define SampleT_INTERRUPT_MASKED_PTR           ( (reg32 *) SampleT_cy_m0s8_tcpwm_1__INTR_MASKED )


/***************************************
*       Registers Constants
***************************************/

/* Mask */
#define SampleT_MASK                           ((uint32)SampleT_cy_m0s8_tcpwm_1__TCPWM_CTRL_MASK)

/* Shift constants for control register */
#define SampleT_RELOAD_CC_SHIFT                (0u)
#define SampleT_RELOAD_PERIOD_SHIFT            (1u)
#define SampleT_PWM_SYNC_KILL_SHIFT            (2u)
#define SampleT_PWM_STOP_KILL_SHIFT            (3u)
#define SampleT_PRESCALER_SHIFT                (8u)
#define SampleT_UPDOWN_SHIFT                   (16u)
#define SampleT_ONESHOT_SHIFT                  (18u)
#define SampleT_QUAD_MODE_SHIFT                (20u)
#define SampleT_INV_OUT_SHIFT                  (20u)
#define SampleT_INV_COMPL_OUT_SHIFT            (21u)
#define SampleT_MODE_SHIFT                     (24u)

/* Mask constants for control register */
#define SampleT_RELOAD_CC_MASK                 ((uint32)(SampleT_1BIT_MASK        <<  \
                                                                            SampleT_RELOAD_CC_SHIFT))
#define SampleT_RELOAD_PERIOD_MASK             ((uint32)(SampleT_1BIT_MASK        <<  \
                                                                            SampleT_RELOAD_PERIOD_SHIFT))
#define SampleT_PWM_SYNC_KILL_MASK             ((uint32)(SampleT_1BIT_MASK        <<  \
                                                                            SampleT_PWM_SYNC_KILL_SHIFT))
#define SampleT_PWM_STOP_KILL_MASK             ((uint32)(SampleT_1BIT_MASK        <<  \
                                                                            SampleT_PWM_STOP_KILL_SHIFT))
#define SampleT_PRESCALER_MASK                 ((uint32)(SampleT_8BIT_MASK        <<  \
                                                                            SampleT_PRESCALER_SHIFT))
#define SampleT_UPDOWN_MASK                    ((uint32)(SampleT_2BIT_MASK        <<  \
                                                                            SampleT_UPDOWN_SHIFT))
#define SampleT_ONESHOT_MASK                   ((uint32)(SampleT_1BIT_MASK        <<  \
                                                                            SampleT_ONESHOT_SHIFT))
#define SampleT_QUAD_MODE_MASK                 ((uint32)(SampleT_3BIT_MASK        <<  \
                                                                            SampleT_QUAD_MODE_SHIFT))
#define SampleT_INV_OUT_MASK                   ((uint32)(SampleT_2BIT_MASK        <<  \
                                                                            SampleT_INV_OUT_SHIFT))
#define SampleT_MODE_MASK                      ((uint32)(SampleT_3BIT_MASK        <<  \
                                                                            SampleT_MODE_SHIFT))

/* Shift constants for trigger control register 1 */
#define SampleT_CAPTURE_SHIFT                  (0u)
#define SampleT_COUNT_SHIFT                    (2u)
#define SampleT_RELOAD_SHIFT                   (4u)
#define SampleT_STOP_SHIFT                     (6u)
#define SampleT_START_SHIFT                    (8u)

/* Mask constants for trigger control register 1 */
#define SampleT_CAPTURE_MASK                   ((uint32)(SampleT_2BIT_MASK        <<  \
                                                                  SampleT_CAPTURE_SHIFT))
#define SampleT_COUNT_MASK                     ((uint32)(SampleT_2BIT_MASK        <<  \
                                                                  SampleT_COUNT_SHIFT))
#define SampleT_RELOAD_MASK                    ((uint32)(SampleT_2BIT_MASK        <<  \
                                                                  SampleT_RELOAD_SHIFT))
#define SampleT_STOP_MASK                      ((uint32)(SampleT_2BIT_MASK        <<  \
                                                                  SampleT_STOP_SHIFT))
#define SampleT_START_MASK                     ((uint32)(SampleT_2BIT_MASK        <<  \
                                                                  SampleT_START_SHIFT))

/* MASK */
#define SampleT_1BIT_MASK                      ((uint32)0x01u)
#define SampleT_2BIT_MASK                      ((uint32)0x03u)
#define SampleT_3BIT_MASK                      ((uint32)0x07u)
#define SampleT_6BIT_MASK                      ((uint32)0x3Fu)
#define SampleT_8BIT_MASK                      ((uint32)0xFFu)
#define SampleT_16BIT_MASK                     ((uint32)0xFFFFu)

/* Shift constant for status register */
#define SampleT_RUNNING_STATUS_SHIFT           (30u)


/***************************************
*    Initial Constants
***************************************/

#define SampleT_CTRL_QUAD_BASE_CONFIG                                                          \
        (((uint32)(SampleT_QUAD_ENCODING_MODES     << SampleT_QUAD_MODE_SHIFT))       |\
         ((uint32)(SampleT_CONFIG                  << SampleT_MODE_SHIFT)))

#define SampleT_CTRL_PWM_BASE_CONFIG                                                           \
        (((uint32)(SampleT_PWM_STOP_EVENT          << SampleT_PWM_STOP_KILL_SHIFT))   |\
         ((uint32)(SampleT_PWM_OUT_INVERT          << SampleT_INV_OUT_SHIFT))         |\
         ((uint32)(SampleT_PWM_OUT_N_INVERT        << SampleT_INV_COMPL_OUT_SHIFT))   |\
         ((uint32)(SampleT_PWM_MODE                << SampleT_MODE_SHIFT)))

#define SampleT_CTRL_PWM_RUN_MODE                                                              \
            ((uint32)(SampleT_PWM_RUN_MODE         << SampleT_ONESHOT_SHIFT))
            
#define SampleT_CTRL_PWM_ALIGN                                                                 \
            ((uint32)(SampleT_PWM_ALIGN            << SampleT_UPDOWN_SHIFT))

#define SampleT_CTRL_PWM_KILL_EVENT                                                            \
             ((uint32)(SampleT_PWM_KILL_EVENT      << SampleT_PWM_SYNC_KILL_SHIFT))

#define SampleT_CTRL_PWM_DEAD_TIME_CYCLE                                                       \
            ((uint32)(SampleT_PWM_DEAD_TIME_CYCLE  << SampleT_PRESCALER_SHIFT))

#define SampleT_CTRL_PWM_PRESCALER                                                             \
            ((uint32)(SampleT_PWM_PRESCALER        << SampleT_PRESCALER_SHIFT))

#define SampleT_CTRL_TIMER_BASE_CONFIG                                                         \
        (((uint32)(SampleT_TC_PRESCALER            << SampleT_PRESCALER_SHIFT))       |\
         ((uint32)(SampleT_TC_COUNTER_MODE         << SampleT_UPDOWN_SHIFT))          |\
         ((uint32)(SampleT_TC_RUN_MODE             << SampleT_ONESHOT_SHIFT))         |\
         ((uint32)(SampleT_TC_COMP_CAP_MODE        << SampleT_MODE_SHIFT)))
        
#define SampleT_QUAD_SIGNALS_MODES                                                             \
        (((uint32)(SampleT_QUAD_PHIA_SIGNAL_MODE   << SampleT_COUNT_SHIFT))           |\
         ((uint32)(SampleT_QUAD_INDEX_SIGNAL_MODE  << SampleT_RELOAD_SHIFT))          |\
         ((uint32)(SampleT_QUAD_STOP_SIGNAL_MODE   << SampleT_STOP_SHIFT))            |\
         ((uint32)(SampleT_QUAD_PHIB_SIGNAL_MODE   << SampleT_START_SHIFT)))

#define SampleT_PWM_SIGNALS_MODES                                                              \
        (((uint32)(SampleT_PWM_SWITCH_SIGNAL_MODE  << SampleT_CAPTURE_SHIFT))         |\
         ((uint32)(SampleT_PWM_COUNT_SIGNAL_MODE   << SampleT_COUNT_SHIFT))           |\
         ((uint32)(SampleT_PWM_RELOAD_SIGNAL_MODE  << SampleT_RELOAD_SHIFT))          |\
         ((uint32)(SampleT_PWM_STOP_SIGNAL_MODE    << SampleT_STOP_SHIFT))            |\
         ((uint32)(SampleT_PWM_START_SIGNAL_MODE   << SampleT_START_SHIFT)))

#define SampleT_TIMER_SIGNALS_MODES                                                            \
        (((uint32)(SampleT_TC_CAPTURE_SIGNAL_MODE  << SampleT_CAPTURE_SHIFT))         |\
         ((uint32)(SampleT_TC_COUNT_SIGNAL_MODE    << SampleT_COUNT_SHIFT))           |\
         ((uint32)(SampleT_TC_RELOAD_SIGNAL_MODE   << SampleT_RELOAD_SHIFT))          |\
         ((uint32)(SampleT_TC_STOP_SIGNAL_MODE     << SampleT_STOP_SHIFT))            |\
         ((uint32)(SampleT_TC_START_SIGNAL_MODE    << SampleT_START_SHIFT)))
        
#define SampleT_TIMER_UPDOWN_CNT_USED                                                          \
                ((SampleT__COUNT_UPDOWN0 == SampleT_TC_COUNTER_MODE)                  ||\
                 (SampleT__COUNT_UPDOWN1 == SampleT_TC_COUNTER_MODE))

#define SampleT_PWM_UPDOWN_CNT_USED                                                            \
                ((SampleT__CENTER == SampleT_PWM_ALIGN)                               ||\
                 (SampleT__ASYMMETRIC == SampleT_PWM_ALIGN))               
        
#define SampleT_PWM_PR_INIT_VALUE              (1u)
#define SampleT_QUAD_PERIOD_INIT_VALUE         (0x8000u)



#endif /* End CY_TCPWM_SampleT_H */

/* [] END OF FILE */
