/*******************************************************************************
* File Name: SAR_intClock.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_SAR_intClock_H)
#define CY_CLOCK_SAR_intClock_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
*        Function Prototypes
***************************************/
#if defined CYREG_PERI_DIV_CMD

void SAR_intClock_StartEx(uint32 alignClkDiv);
#define SAR_intClock_Start() \
    SAR_intClock_StartEx(SAR_intClock__PA_DIV_ID)

#else

void SAR_intClock_Start(void);

#endif/* CYREG_PERI_DIV_CMD */

void SAR_intClock_Stop(void);

void SAR_intClock_SetFractionalDividerRegister(uint16 clkDivider, uint8 clkFractional);

uint16 SAR_intClock_GetDividerRegister(void);
uint8  SAR_intClock_GetFractionalDividerRegister(void);

#define SAR_intClock_Enable()                         SAR_intClock_Start()
#define SAR_intClock_Disable()                        SAR_intClock_Stop()
#define SAR_intClock_SetDividerRegister(clkDivider, reset)  \
    SAR_intClock_SetFractionalDividerRegister((clkDivider), 0u)
#define SAR_intClock_SetDivider(clkDivider)           SAR_intClock_SetDividerRegister((clkDivider), 1u)
#define SAR_intClock_SetDividerValue(clkDivider)      SAR_intClock_SetDividerRegister((clkDivider) - 1u, 1u)


/***************************************
*             Registers
***************************************/
#if defined CYREG_PERI_DIV_CMD

#define SAR_intClock_DIV_ID     SAR_intClock__DIV_ID

#define SAR_intClock_CMD_REG    (*(reg32 *)CYREG_PERI_DIV_CMD)
#define SAR_intClock_CTRL_REG   (*(reg32 *)SAR_intClock__CTRL_REGISTER)
#define SAR_intClock_DIV_REG    (*(reg32 *)SAR_intClock__DIV_REGISTER)

#define SAR_intClock_CMD_DIV_SHIFT          (0u)
#define SAR_intClock_CMD_PA_DIV_SHIFT       (8u)
#define SAR_intClock_CMD_DISABLE_SHIFT      (30u)
#define SAR_intClock_CMD_ENABLE_SHIFT       (31u)

#define SAR_intClock_CMD_DISABLE_MASK       ((uint32)((uint32)1u << SAR_intClock_CMD_DISABLE_SHIFT))
#define SAR_intClock_CMD_ENABLE_MASK        ((uint32)((uint32)1u << SAR_intClock_CMD_ENABLE_SHIFT))

#define SAR_intClock_DIV_FRAC_MASK  (0x000000F8u)
#define SAR_intClock_DIV_FRAC_SHIFT (3u)
#define SAR_intClock_DIV_INT_MASK   (0xFFFFFF00u)
#define SAR_intClock_DIV_INT_SHIFT  (8u)

#else 

#define SAR_intClock_DIV_REG        (*(reg32 *)SAR_intClock__REGISTER)
#define SAR_intClock_ENABLE_REG     SAR_intClock_DIV_REG
#define SAR_intClock_DIV_FRAC_MASK  SAR_intClock__FRAC_MASK
#define SAR_intClock_DIV_FRAC_SHIFT (16u)
#define SAR_intClock_DIV_INT_MASK   SAR_intClock__DIVIDER_MASK
#define SAR_intClock_DIV_INT_SHIFT  (0u)

#endif/* CYREG_PERI_DIV_CMD */

#endif /* !defined(CY_CLOCK_SAR_intClock_H) */

/* [] END OF FILE */
