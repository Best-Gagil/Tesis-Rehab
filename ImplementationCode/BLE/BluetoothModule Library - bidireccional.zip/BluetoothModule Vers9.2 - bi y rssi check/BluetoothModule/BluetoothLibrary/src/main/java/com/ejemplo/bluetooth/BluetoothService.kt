package com.ejemplo.bluetooth

import android.os.*
import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.webkit.JavascriptInterface
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.os.ParcelUuid
import java.lang.reflect.Method
import java.util.*

@RequiresApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
class BluetoothService(private val context: Context) {

    companion object {
        private var instance: BluetoothService? = null
        private var unitySendMessageMethod: Method? = null

        @JvmStatic
        fun getInstance(activity: Activity): BluetoothService {
            if (instance == null) {
                instance = BluetoothService(activity.applicationContext)
            }
            return instance!!
        }

        init {
            try {
                val unityPlayer = Class.forName("com.unity3d.player.UnityPlayer")
                unitySendMessageMethod = unityPlayer.getMethod(
                    "UnitySendMessage",
                    String::class.java,
                    String::class.java,
                    String::class.java
                )
            } catch (e: Exception) {
                Log.e("BluetoothService", "Error inicializando UnitySendMessage", e)
            }
        }
    }

    private val REQUEST_CODE = 1
    private var stopScanRunnable: Runnable? = null

    // UUIDs para envío
    private lateinit var ServiceEnviarHex_UUID: UUID
    private lateinit var CharacteristicEnviando_UUID: UUID

    // UUIDs para recepción (opcionales; si no se asignan, se asume mismos que envío)
    private var ServiceRecibirHex_UUID: UUID? = null
    private var CharacteristicRecibiendo_UUID: UUID? = null

    // Descriptor para habilitar notificaciones (por defecto CCCD 0x2902)
    private var DescriptorRecibiendo_UUID: UUID =
        UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    private var bluetoothGatt: BluetoothGatt? = null

    private val bluetoothAdapter: BluetoothAdapter? by lazy {
        val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothManager.adapter
    }

    private val handler = Handler(Looper.getMainLooper())
    private var scanCallback: ScanCallback? = null

    private var rssiHandler = Handler(Looper.getMainLooper())
    private var rssiRunnable: Runnable? = null
    private var rssiIntervalMs = 500L
    private var isConnected = false

    // Cache de características resueltas tras discoverServices()
    private var txChar: BluetoothGattCharacteristic? = null
    private var rxChar: BluetoothGattCharacteristic? = null

    // Flag para retry único de INDICATE si CCCD con NOTIFY falla con 133
    private var triedIndicateFallback = false

    // ================================
    // AÑADIDO — Throttle RSSI en escaneo
    // ================================
    private val lastScanRssiSentAt = mutableMapOf<String, Long>() // AÑADIDO: MAC -> ts último envío
    private var minScanRssiUpdateMs = 400L                         // AÑADIDO: anti-spam escaneo

    /****************************************************************************************************
     *                               FUNCIÓN PRINCIPAL DE ESCANEO                                        *
     ****************************************************************************************************/
    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    @JavascriptInterface
    @SuppressLint("MissingPermission")
    fun startScan(bleParams: Array<String>) {
        // Limpia escaneo previo
        scanCallback?.let {
            bluetoothAdapter?.bluetoothLeScanner?.stopScan(it)
            stopScanRunnable?.let { r -> handler.removeCallbacks(r) }
            scanCallback = null
        }

        Log.d("AndroidStudio", "[BLE][SCAN] startScan() con ${bleParams.size} parámetros: ${bleParams.joinToString()}")

        if (bleParams.size < 2) {
            UnitySendMessage("BluetoothManager", "OnError", "Parámetros incompletos en startScan")
            return
        }

        // [0] Servicio para enviar (y por defecto, recibir)
        ServiceEnviarHex_UUID = UUID.fromString(bleParams[0])
        // [1] Característica para enviar
        CharacteristicEnviando_UUID = UUID.fromString(bleParams[1])

        // [2] (opcional) Característica para recibir
        CharacteristicRecibiendo_UUID = if (bleParams.size >= 3)
            UUID.fromString(bleParams[2])
        else
            CharacteristicEnviando_UUID // por si el periférico usa la misma característica con notify

        // [3] (opcional) Servicio para recibir
        ServiceRecibirHex_UUID = if (bleParams.size >= 4)
            UUID.fromString(bleParams[3])
        else
            ServiceEnviarHex_UUID // por defecto, mismo servicio

        // [4] (opcional) Descriptor para notificaciones
        if (bleParams.size >= 5) {
            try {
                DescriptorRecibiendo_UUID = UUID.fromString(bleParams[4])
            } catch (_: Exception) {
                Log.w("AndroidStudio", "[BLE][SCAN] Descriptor invalido, uso CCCD por defecto 0x2902")
            }
        }

        Log.d(
            "AndroidStudio",
            "[BLE][SCAN] Params → SvcTX=$ServiceEnviarHex_UUID, CharTX=$CharacteristicEnviando_UUID, " +
                    "CharRX=$CharacteristicRecibiendo_UUID, SvcRX=$ServiceRecibirHex_UUID, CCCD=$DescriptorRecibiendo_UUID"
        )

        val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val btAdapter = bluetoothManager.adapter
        val bluetoothLeScanner = btAdapter?.bluetoothLeScanner

        if (btAdapter == null || !btAdapter.isEnabled || bluetoothLeScanner == null) {
            UnitySendMessage("BluetoothManager", "OnError", "Bluetooth no disponible")
            Log.e("AndroidStudio", "[BLE][SCAN] Adapter nulo/BT apagado/Scanner nulo")
            return
        }

        scanCallback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult?) {
                result?.device?.let { device ->
                    val name = device.name ?: "Desconocido"
                    val rssi = result.rssi
                    val mac = device.address
                    UnitySendMessage("BluetoothManager", "OnDeviceFound", "$name|$mac|$rssi")
                    Log.d("AndroidStudio", "[BLE][SCAN] found: $name ($mac) RSSI=$rssi")

                    // ==========================
                    // AÑADIDO: RSSI en ESCANEO
                    // ==========================
                    // Enviar actualizaciones de señal durante el escaneo con un pequeño throttle
                    val now = android.os.SystemClock.elapsedRealtime()
                    val last = lastScanRssiSentAt[mac] ?: 0L
                    if (now - last >= minScanRssiUpdateMs) {
                        lastScanRssiSentAt[mac] = now
                        // Mantengo OnDeviceFound intacto y AÑADO un canal dedicado para refrescar barras en lista
                        UnitySendMessage("BluetoothManager", "OnScanRssiUpdate", "$mac|$rssi")
                    }
                }
            }

            override fun onScanFailed(errorCode: Int) {
                UnitySendMessage("BluetoothManager", "OnError", "Error en escaneo: $errorCode")
                Log.e("AndroidStudio", "[BLE][SCAN] onScanFailed: $errorCode")
            }
        }

        val scanSettings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()

        val filter = ScanFilter.Builder()
            .setServiceUuid(ParcelUuid(ServiceEnviarHex_UUID))
            .build()

        Log.d("AndroidStudio", "[BLE][SCAN] Iniciando scan con filtro por servicio $ServiceEnviarHex_UUID")
        bluetoothLeScanner.startScan(listOf(filter), scanSettings, scanCallback)

        stopScanRunnable = Runnable {
            bluetoothLeScanner.stopScan(scanCallback)
            UnitySendMessage("BluetoothManager", "OnScanFinished", "Finalizado")
            Log.d("AndroidStudio", "[BLE][SCAN] Scan detenido por timeout")
        }
        handler.postDelayed(stopScanRunnable!!, 4000)
    }

    /****************************************************************************************************
     *                            FUNCIÓN PRINCIPAL DE CONEXIÓN CON DISPOSITIVO                          *
     ****************************************************************************************************/
    @JavascriptInterface
    @SuppressLint("MissingPermission")
    fun connectToDevice(deviceName: String, macAddress: String) {
        Log.i("AndroidStudio", "[BLE][CONN] connectToDevice → name=$deviceName, mac=$macAddress")

        val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val btAdapter = bluetoothManager.adapter
        val device = try { btAdapter.getRemoteDevice(macAddress) } catch (e: Exception) { null }

        if (device == null) {
            UnitySendMessage("BluetoothManager", "OnError", "Dispositivo no encontrado: $deviceName ($macAddress)")
            Log.e("AndroidStudio", "[BLE][CONN] getRemoteDevice devolvió null")
            return
        }

        val unityActivity: Activity? = try {
            val clazz = Class.forName("com.unity3d.player.UnityPlayer")
            val field = clazz.getDeclaredField("currentActivity")
            field.isAccessible = true
            field.get(null) as? Activity
        } catch (e: Exception) {
            Log.w("AndroidStudio", "[BLE][CONN] No pude obtener currentActivity, uso null", e)
            null
        }

        Log.d("AndroidStudio", "[BLE][CONN] Llamando connectGatt (autoConnect=false) ...")
        bluetoothGatt = device.connectGatt(unityActivity, false, gattCallback)
    }

    /****************************************************************************************************
     *                               FUNCIÓN PRINCIPAL DE ENVÍO DE DATO HEX                              *
     ****************************************************************************************************/
    @JavascriptInterface
    fun sendData(hexData: String) {
        val gatt = bluetoothGatt ?: run {
            UnitySendMessage("BluetoothManager", "OnError", "No hay conexión GATT activa")
            Log.e("AndroidStudio", "[BLE][TX] Sin GATT activo")
            return
        }

        val ch = txChar ?: run {
            UnitySendMessage("BluetoothManager", "OnError", "TX no resuelta; espera discoverServices()")
            Log.e("AndroidStudio", "[BLE][TX] txChar nula (no resuelta)")
            return
        }

        val bytes = hexStringToByteArray(hexData)
        if (bytes.isEmpty()) {
            UnitySendMessage("BluetoothManager", "OnError", "Payload vacío o inválido")
            return
        }

        // ✅ Chequeo de permiso requerido en Android 12+ antes de escribir
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT)
            != PackageManager.PERMISSION_GRANTED) {
            UnitySendMessage("BluetoothManager", "OnError",
                "Permiso BLUETOOTH_CONNECT requerido para escribir")
            Log.e("AndroidStudio", "[BLE][TX] Falta BLUETOOTH_CONNECT para escribir")
            return
        }

        val p = ch.properties
        ch.writeType = if ((p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0)
            BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        else
            BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT

        try {
            val ok = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val status = gatt.writeCharacteristic(ch, bytes, ch.writeType)
                Log.d("AndroidStudio", "[BLE][TX] write(T+) statusCode=$status len=${bytes.size}")
                if (status == BluetoothStatusCodes.SUCCESS) true
                else {
                    // Fallback legacy si el stack devuelve un código diferente a SUCCESS
                    @Suppress("DEPRECATION")
                    run {
                        ch.value = bytes
                        val enq = gatt.writeCharacteristic(ch)
                        Log.w("AndroidStudio", "[BLE][TX] Fallback legacy write() enqueued=$enq")
                        enq
                    }
                }
            } else {
                @Suppress("DEPRECATION")
                run {
                    ch.value = bytes
                    val enq = gatt.writeCharacteristic(ch)
                    Log.d("AndroidStudio", "[BLE][TX] write(legacy) enqueued=$enq len=${bytes.size}")
                    enq
                }
            }

            if (!ok) {
                UnitySendMessage("BluetoothManager", "OnError", "Error al escribir en la característica")
            } else {
                UnitySendMessage("BluetoothManager", "OnDataSent", hexData)
            }
        } catch (se: SecurityException) {
            UnitySendMessage("BluetoothManager", "OnError", "Sin permiso BLUETOOTH_CONNECT")
            Log.e("AndroidStudio", "[BLE][TX] SecurityException al escribir: ${se.message}", se)
        } catch (e: Exception) {
            UnitySendMessage("BluetoothManager", "OnError", "Excepción al escribir")
            Log.e("AndroidStudio", "[BLE][TX] Excepción al escribir: ${e.message}", e)
        }
    }

    /****************************************************************************************************
     *                      FUNCIÓN OPCIONAL PARA HABILITAR NOTIFICACIONES MANUAL                        *
     ****************************************************************************************************/
    @JavascriptInterface
    @SuppressLint("MissingPermission")
    fun enableNotifications() {
        val gatt = bluetoothGatt ?: run {
            UnitySendMessage("BluetoothManager", "OnError", "No hay conexión GATT activa para notificaciones")
            Log.e("AndroidStudio", "[BLE][NOTIFY] Sin GATT activo")
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            UnitySendMessage("BluetoothManager", "OnError", "Permiso BLUETOOTH_CONNECT requerido para habilitar notificaciones")
            Log.e("AndroidStudio", "[BLE][NOTIFY] Falta BLUETOOTH_CONNECT")
            return
        }

        val characteristic = rxChar ?: run {
            UnitySendMessage("BluetoothManager", "OnError", "RX no resuelta; espera discoverServices()")
            Log.e("AndroidStudio", "[BLE][NOTIFY] rxChar nula (no resuelta)")
            return
        }

        val okSet = gatt.setCharacteristicNotification(characteristic, true)
        Log.d("AndroidStudio", "[BLE][NOTIFY] setCharacteristicNotification(true) → $okSet")
        if (!okSet) {
            UnitySendMessage("BluetoothManager", "OnError", "No se pudo habilitar notificaciones (setCharacteristicNotification)")
            return
        }

        val cccd = characteristic.getDescriptor(DescriptorRecibiendo_UUID)
        if (cccd != null) {
            val hasNotify = (characteristic.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0
            val okWrite = writeCccd(gatt, cccd, useIndicate = !hasNotify)
            if (!okWrite) {
                UnitySendMessage("BluetoothManager", "OnError",
                    "No se pudo escribir el descriptor de notificación")
                return
            }
        } else {
            Log.w("AndroidStudio", "[BLE][NOTIFY] CCCD $DescriptorRecibiendo_UUID no encontrado; relying on setCharacteristicNotification")
        }
    }

    /****************************************************************************************************
     *                               FUNCIÓN PRINCIPAL DE DESCONEXIÓN                                    *
     ****************************************************************************************************/
    @JavascriptInterface
    @SuppressLint("MissingPermission")
    fun disconnect() {
        isConnected = false
        stopRssiMonitoring()
        Log.i("AndroidStudio", "[BLE][CONN] disconnect() solicitado")

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED) {

            bluetoothGatt?.disconnect()
            bluetoothGatt?.close()
            bluetoothGatt = null
            UnitySendMessage("BluetoothManager", "OnDeviceDisconnected", "Disconnected")
            Log.d("AndroidStudio", "[BLE][CONN] GATT cerrado")

        } else {
            UnitySendMessage("BluetoothManager", "OnError", "No tienes permisos para usar Bluetooth")
            Log.e("AndroidStudio", "[BLE][CONN] Falta BLUETOOTH_CONNECT para desconectar")
            if (context is Activity) {
                ActivityCompat.requestPermissions(
                    context as Activity,
                    arrayOf(Manifest.permission.BLUETOOTH_CONNECT),
                    REQUEST_CODE
                )
            }
        }
    }

    /****************************************************************************************************
     *                  FUNCIÓN SECUNDARIA DE TRANSMISIÓN REALTIME DE RSSI                               *
     ****************************************************************************************************/
    @JavascriptInterface
    fun setRssiIntervalMs(ms: Int) {
        rssiIntervalMs = ms.coerceIn(200, 5000).toLong()
        Log.d("AndroidStudio", "[BLE][RSSI] Intervalo fijado en ${rssiIntervalMs}ms")
        if (isConnected) startRssiMonitoring()
    }

    @SuppressLint("MissingPermission")
    private fun startRssiMonitoring() {
        stopRssiMonitoring()
        rssiRunnable = object : Runnable {
            override fun run() {
                if (isConnected) {
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
                        ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED) {
                        bluetoothGatt?.readRemoteRssi()
                    }
                    rssiHandler.postDelayed(this, rssiIntervalMs)
                }
            }
        }
        rssiHandler.post(rssiRunnable!!)
        Log.d("AndroidStudio", "[BLE][RSSI] Monitoreo iniciado")
    }

    private fun stopRssiMonitoring() {
        rssiRunnable?.let { rssiHandler.removeCallbacks(it) }
        rssiRunnable = null
        Log.d("AndroidStudio", "[BLE][RSSI] Monitoreo detenido")
    }

    /****************************************************************************************************
     *                  FUNCIÓN SECUNDARIA DE CONVERSIÓN HEX <-> BYTES                                   *
     ****************************************************************************************************/
    private fun hexStringToByteArray(s: String): ByteArray {
        return try {
            s.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
        } catch (e: NumberFormatException) {
            Log.e("AndroidStudio", "[BLE] Error al convertir hexadecimal a byte array: ${e.message}")
            byteArrayOf()
        }
    }

    private fun bytesToHex(bytes: ByteArray?): String {
        if (bytes == null) return ""
        val sb = StringBuilder()
        for (b in bytes) sb.append(String.format("%02X", b))
        return sb.toString()
    }

    /****************************************************************************************************
     *                  FUNCIÓN SECUNDARIA DE ENVÍO DE MENSAJES A UNITY                                  *
     ****************************************************************************************************/
    private fun UnitySendMessage(gameObject: String, method: String, message: String) {
        try {
            unitySendMessageMethod?.invoke(null, gameObject, method, message)
        } catch (e: Exception) {
            Log.e("BluetoothService", "Error enviando mensaje a Unity: ${e.message}", e)
        }
    }

    /****************************************************************************************************
     *               CALLBACK GATT: ESTADO, SERVICIOS, NOTIFICACIONES, DESCRIPTORES Y RSSI               *
     ****************************************************************************************************/
    private val gattCallback = object : BluetoothGattCallback() {

        override fun onConnectionStateChange(gatt: BluetoothGatt?, status: Int, newState: Int) {
            Log.d("AndroidStudio", "[BLE][CONN] onConnectionStateChange status=$status newState=$newState")
            when (newState) {
                BluetoothProfile.STATE_CONNECTED -> {
                    isConnected = true
                    triedIndicateFallback = false // reset fallback al conectar
                    Log.d("AndroidStudio", "[BLE][CONN] Conexión GATT exitosa con ${gatt?.device?.address}, descubriendo servicios...")
                    UnitySendMessage("BluetoothManager", "OnConnectionResult", "true")

                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
                        ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED) {
                        gatt?.discoverServices()
                    } else {
                        Log.e("AndroidStudio", "[BLE][CONN] Sin permiso BLUETOOTH_CONNECT → no discoverServices()")
                    }
                }

                BluetoothProfile.STATE_DISCONNECTED -> {
                    isConnected = false
                    Log.w("AndroidStudio", "[BLE][CONN] Desconectado de ${gatt?.device?.address}, cerrando conexión")
                    // ==========================
                    // AÑADIDO: asegurar parar RSSI si la desconexión no vino de disconnect()
                    // ==========================
                    stopRssiMonitoring()

                    UnitySendMessage("BluetoothManager", "OnConnectionResult", "false")
                    bluetoothGatt?.close()
                    bluetoothGatt = null
                }

                else -> {
                    Log.w("AndroidStudio", "[BLE][CONN] Cambio de estado desconocido: $newState (status=$status)")
                }
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            Log.d("AndroidStudio", "[BLE][DISC] onServicesDiscovered status=$status")
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.d("AndroidStudio", "[BLE][DISC] Servicios descubiertos en ${gatt.device.address}")

                // Listado opcional para diagnóstico
                gatt.services?.forEach { svc ->
                    Log.d("AndroidStudio", "[BLE][DISC] Service: ${svc.uuid}")
                    svc.characteristics?.forEach { ch ->
                        val p = ch.properties
                        val props = buildList {
                            if ((p and BluetoothGattCharacteristic.PROPERTY_READ) != 0) add("READ")
                            if ((p and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0) add("WRITE")
                            if ((p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) add("WRITE_NR")
                            if ((p and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0) add("NOTIFY")
                            if ((p and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) add("INDICATE")
                        }.joinToString("|")
                        Log.d("AndroidStudio", "[BLE][DISC]   Char ${ch.uuid} props=$props")
                    }
                }

                // Resolver y cachear TX/RX correctas
                resolveGattHandles(gatt)

                // Pequeño delay antes de habilitar NOTIFY (evita 133 en muchos periféricos)
                if (rxChar != null) {
                    handler.postDelayed({
                        try {
                            Log.d("AndroidStudio", "[BLE][NOTIFY] (delay) habilitando notificaciones en: ${rxChar!!.uuid}")
                            enableNotifications()
                        } catch (e: Exception) {
                            Log.e("AndroidStudio", "[BLE][NOTIFY] Error habilitando notificaciones: ${e.message}", e)
                        }
                    }, 300)
                } else {
                    Log.w("AndroidStudio", "[BLE][NOTIFY] RX no resuelta; no se habilitan notificaciones")
                }

                // ==========================
                // AÑADIDO: iniciar monitoreo RSSI al tener servicios listos
                // ==========================
                handler.postDelayed({ startRssiMonitoring() }, 500)

            } else {
                Log.e("AndroidStudio", "[BLE][DISC] Fallo al descubrir servicios. Status=$status")
            }
        }

        override fun onDescriptorWrite(
            gatt: BluetoothGatt,
            descriptor: BluetoothGattDescriptor,
            status: Int
        ) {
            Log.d(
                "AndroidStudio",
                "[BLE][NOTIFY] onDescriptorWrite uuid=${descriptor.uuid} status=$status (GATT_SUCCESS=${BluetoothGatt.GATT_SUCCESS})"
            )

            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.i("AndroidStudio", "[BLE][NOTIFY] CCCD escrito correctamente (notificaciones habilitadas)")
                return
            }

            // Retry único: si falló con 133 (error genérico) o FAILURE, y la RX soporta INDICATE, intenta ese modo
            if ((status == 133 || status == BluetoothGatt.GATT_FAILURE) &&
                !triedIndicateFallback &&
                rxChar != null &&
                descriptor.uuid == DescriptorRecibiendo_UUID) {

                val hasInd = (rxChar!!.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0
                if (hasInd) {
                    triedIndicateFallback = true
                    Log.w("AndroidStudio", "[BLE][NOTIFY] CCCD=133; intentando INDICATE como fallback")
                    try {
                        val ok = writeCccd(gatt, descriptor, useIndicate = true)
                        Log.d("AndroidStudio", "[BLE][NOTIFY] writeDescriptor(INDICATE via helper) → $ok")
                        return
                    } catch (e: Exception) {
                        Log.e("AndroidStudio", "[BLE][NOTIFY] Fallback INDICATE lanzó excepción: ${e.message}", e)
                    }
                } else {
                    Log.w("AndroidStudio", "[BLE][NOTIFY] CCCD=133 y la char no tiene INDICATE; no hay fallback")
                }
            }

            Log.e("AndroidStudio", "[BLE][NOTIFY] Escritura de CCCD falló con status=$status")
        }

        override fun onCharacteristicWrite(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            status: Int
        ) {
            Log.d(
                "AndroidStudio",
                "[BLE][TX] onCharacteristicWrite uuid=${characteristic.uuid} status=$status (GATT_SUCCESS=${BluetoothGatt.GATT_SUCCESS})"
            )
            if (status != BluetoothGatt.GATT_SUCCESS) {
                Log.e("AndroidStudio", "[BLE][TX] Error en escritura: status=$status")
            }
        }

        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            val hex = bytesToHex(characteristic.value)
            val tRecv = android.os.SystemClock.elapsedRealtimeNanos()  // reloj estable
            UnitySendMessage("BluetoothManager", "OnDataReceived", hex)
        }

        override fun onCharacteristicRead(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            Log.d("AndroidStudio", "[BLE][READ] onCharacteristicRead uuid=${characteristic.uuid} status=$status")
            if (status == BluetoothGatt.GATT_SUCCESS) {
                val hex = bytesToHex(characteristic.value)
                Log.d("AndroidStudio", "[BLE][READ] Lectura exitosa: HEX=$hex")
                UnitySendMessage("BluetoothManager", "OnDataReceived", hex)
            } else {
                Log.e("AndroidStudio", "[BLE][READ] Error al leer ${characteristic.uuid}, status=$status")
            }
        }

        override fun onReadRemoteRssi(gatt: BluetoothGatt, rssi: Int, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                UnitySendMessage("BluetoothManager", "OnRssiUpdate", rssi.toString())
            } else {
                Log.e("AndroidStudio", "[BLE][RSSI] Fallo al leer RSSI, status=$status")
            }
        }
    }

    // Resolver y cachear TX/RX tras discoverServices()
    private fun resolveGattHandles(gatt: BluetoothGatt) {
        txChar = null
        rxChar = null
        triedIndicateFallback = false

        gatt.services?.forEach { svc ->
            svc.characteristics?.forEach { ch ->
                val p = ch.properties
                val hasWrite   = (p and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0
                val hasWriteNR = (p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
                val hasNotify  = (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0
                val hasInd     = (p and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0

                if (ch.uuid == CharacteristicEnviando_UUID && (hasWrite || hasWriteNR)) {
                    txChar = ch
                    Log.d("AndroidStudio", "[BLE][DISC] TX encontrada ${ch.uuid} props=WRITE=$hasWrite|WRITE_NR=$hasWriteNR en svc ${svc.uuid}")
                }
                if (CharacteristicRecibiendo_UUID != null &&
                    ch.uuid == CharacteristicRecibiendo_UUID && (hasNotify || hasInd)) {
                    rxChar = ch
                    Log.d("AndroidStudio", "[BLE][DISC] RX encontrada ${ch.uuid} props=NOTIFY=$hasNotify|INDICATE=$hasInd en svc ${svc.uuid}")
                }
            }
        }

        if (txChar == null) Log.e("AndroidStudio", "[BLE][DISC] ❌ No se encontró TX con permisos de escritura")
        if (rxChar == null && CharacteristicRecibiendo_UUID != null)
            Log.w("AndroidStudio", "[BLE][DISC] ⚠️ No se encontró RX con NOTIFY/INDICATE")
    }

    /****************************************************************************************************
     *                               HELPER para escribir CCCD (permiso + API T+)                        *
     ****************************************************************************************************/
    @SuppressLint("MissingPermission")
    private fun writeCccd(
        gatt: BluetoothGatt,
        cccd: BluetoothGattDescriptor,
        useIndicate: Boolean
    ): Boolean {
        val value = if (useIndicate)
            BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
        else
            BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT)
            != PackageManager.PERMISSION_GRANTED) {
            Log.e("AndroidStudio", "[BLE][NOTIFY] Falta permiso BLUETOOTH_CONNECT para escribir CCCD")
            UnitySendMessage("BluetoothManager", "OnError",
                "Permiso BLUETOOTH_CONNECT requerido para habilitar notificaciones")
            return false
        }

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val status = gatt.writeDescriptor(cccd, value)
            Log.d("AndroidStudio", "[BLE][NOTIFY] writeDescriptor(T+) status=$status (indicate=$useIndicate)")
            status == BluetoothStatusCodes.SUCCESS
        } else {
            @Suppress("DEPRECATION")
            run {
                cccd.value = value
                val ok = gatt.writeDescriptor(cccd)
                Log.d("AndroidStudio", "[BLE][NOTIFY] writeDescriptor(legacy) enqueued=$ok (indicate=$useIndicate)")
                ok
            }
        }
    }
}
